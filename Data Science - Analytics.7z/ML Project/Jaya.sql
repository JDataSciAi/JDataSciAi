-- Customers
CREATE TABLE customers (
    customer_id   NUMBER PRIMARY KEY,
    name          VARCHAR2(50),
    age           NUMBER,
    gender        VARCHAR2(10),
    location      VARCHAR2(50),
    loyalty_tier  VARCHAR2(20)
);

--Transactions
CREATE TABLE transactions (
    transaction_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES customers(customer_id),
    amount NUMBER,
    payment_method VARCHAR2(50),
    is_fraud NUMBER(1), -- 0 = No, 1 = Yes
    timestamp DATE
);

--Orders (Sales History)
CREATE TABLE orders (
    order_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES customers(customer_id),
    product_id NUMBER,
    quantity NUMBER,
    amount NUMBER,
    order_date DATE
);

--Products
CREATE TABLE products (
    product_id NUMBER PRIMARY KEY,
    category VARCHAR2(50),
    price NUMBER,
    rating NUMBER,
    stock_quantity NUMBER
);

--Customer Activity (Behavior)
CREATE TABLE customer_activity (
    activity_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES customers(customer_id),
    session_id VARCHAR2(50),
    page_views NUMBER,
    clicks NUMBER,
    purchases NUMBER,
    timestamp DATE
);

INSERT INTO customers VALUES (1, 'Alice', 28, 'F', 'Nagpur', 'Gold');
INSERT INTO customers VALUES (2, 'Bob', 35, 'M', 'Pune', 'Silver');
INSERT INTO customers VALUES (3, 'Angela', 20, 'F', 'Mumbai', 'Bronze');
INSERT INTO customers VALUES (4, 'John', 55, 'M', 'Delhi', 'Gold');
INSERT INTO customers VALUES (5, 'Larry', 25, 'M', 'Nagpur', 'Gold');
INSERT INTO products VALUES (101, 'Electronics', 1500, 4.5, 20);
INSERT INTO products VALUES (102, 'Clothing', 500, 4.0, 50);
INSERT INTO products VALUES (103, 'Beauty', 600, 3.8, 30);
INSERT INTO products VALUES (104, 'Health', 2000, 4.8, 50);
INSERT INTO products VALUES (105, 'Furniture', 5000, 4.2, 10);
INSERT INTO transactions VALUES (5001, 1, 1500, 'Credit Card', 0, SYSDATE);
INSERT INTO transactions VALUES (5002, 2, 2000, 'Credit Card', 0, SYSDATE);
INSERT INTO transactions VALUES (5003, 3, 600, 'Credit Card', 1, SYSDATE);
INSERT INTO transactions VALUES (5004, 4, 5000, 'Credit Card', 0, SYSDATE);
INSERT INTO transactions VALUES (5005, 5, 500, 'Credit Card', 1, SYSDATE);

select *from transactions;
select c.gender from customers c;

ALTER TABLE transactions ADD product_id NUMBER;
INSERT INTO transactions VALUES (5001, 1, 1500, 'Credit Card', 0, SYSDATE, 101);
INSERT INTO transactions VALUES (5002, 2, 2000, 'Credit Card', 0, SYSDATE,102);
INSERT INTO transactions VALUES (5003, 3, 600, 'Credit Card', 1, SYSDATE,103);
INSERT INTO transactions VALUES (5004, 4, 5000, 'Credit Card', 0, SYSDATE,104);
INSERT INTO transactions VALUES (5005, 5, 500, 'Credit Card', 1, SYSDATE,105);

UPDATE transactions
SET amount = 500, product_id = 105
WHERE transaction_id = 5005;
commit;
SELECT t.transaction_id, t.amount, t.is_fraud,
       o.product_id, p.category, p.price, p.rating
FROM transactions t
JOIN orders o ON t.transaction_id = o.order_id
JOIN products p ON o.product_id = p.product_id;

SELECT t.transaction_id, t.customer_id, t.amount, t.payment_method, t.is_fraud,
       c.age, c.gender, c.location, c.loyalty_tier,
       p.category, p.price, p.rating
FROM transactions t
JOIN customers c ON t.customer_id = c.customer_id
JOIN products p ON t.product_id = p.product_id;

--Creating Alias
SELECT 
    t.transaction_id   AS transaction_id,
    t.customer_id      AS customer_id,
    t.amount           AS amount,
    t.payment_method   AS payment_method,
    t.is_fraud         AS is_fraud,
    c.age              AS age,
    c.gender           AS gender,
    c.location         AS location,
    c.loyalty_tier     AS loyalty_tier,
    p.category         AS category,
    p.price            AS price,
    p.rating           AS rating
FROM transactions t
JOIN customers c ON t.customer_id = c.customer_id
JOIN products p  ON t.product_id = p.product_id;


