# toll_module.py

def show_vehicle_types():
    print("\n🚗 Vehicle Types and Toll Rates:")
    print("Car    → ₹50")
    print("Truck  → ₹100")
    print("Bus    → ₹80")
    print("Bike   → ₹20")

def calculate_toll(vehicle_type):
    if vehicle_type == "Car":
        print("Toll Charged: ₹50")
        return 50
    elif vehicle_type == "Truck":
        print("Toll Charged: ₹100")
        return 100
    elif vehicle_type == "Bus":
        print("Toll Charged: ₹80")
        return 80
    elif vehicle_type == "Bike":
        print("Toll Charged: ₹20")
        return 20
    else:
        print("❌ Unknown vehicle type. No toll charged.")
        return 0

def show_receipt(vehicle_type, amount):
    print(f"🧾 Receipt → Vehicle: {vehicle_type} | Toll: ₹{amount}")