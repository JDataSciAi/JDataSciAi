# billing_utils.py

cart = []

def add_item(name, price, quantity):
    total_price = price * quantity
    cart.append({
        "name": name,
        "price": price,
        "quantity": quantity,
        "total": total_price
    })
    print(f"✅ {quantity} x {name} added. Total: ₹{total_price}")

def calculate_bill():
    subtotal = 0
    for item in cart:
        subtotal += item["total"]

    discount = 0
    if subtotal > 1000:
        discount = subtotal * 0.1  # 10% discount

    tax = (subtotal - discount) * 0.05  # 5% GST
    final_total = subtotal - discount + tax

    print("\n BILL SUMMARY")
    print("----------------------------")
    for item in cart:
        print(f"{item['quantity']} x {item['name']} @ ₹{item['price']} = ₹{item['total']}")
    print("----------------------------")
    print(f"Subtotal: ₹{subtotal}")
    print(f"Discount (10%): ₹{round(discount, 2)}")
    print(f"GST (5%): ₹{round(tax, 2)}")
    print(f"Total Payable: ₹{round(final_total, 2)}")

def print_receipt_pattern():
    print("\n RECEIPT PATTERN QUANTITY-WISE")
    for item in cart:
        print(f"{item['name']}: " + "* " * item["quantity"])
    print("\n RECEIPT PATTERN COST-WISE")
    for item in cart:
        cost= int(item["price"]//10)
        print(f"{item['name']}: " + "* " * cost)

